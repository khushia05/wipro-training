// here we will define the EventConstraint class
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Http;

public class EventConstraint : IRouteConstraint
{
    public bool Match(HttpContext httpContext, IRouter route, string routeKey, RouteValueDictionary values, RouteDirection routeDirection)
    {
        if (httpContext == null || route == null || values == null)
        {
            return false;
        }
        // if (values.TryGetValue(routeKey, out var value) && value is int intValue)
        // {
        //     return intValue % 2 == 0;
        //     // Here we can implement our custom constraint logic
        // }
        if (int.TryParse(values[routeKey]?.ToString(), out int intValue))
        {
            return intValue % 2 == 0;
        }

        return false;
    }
}