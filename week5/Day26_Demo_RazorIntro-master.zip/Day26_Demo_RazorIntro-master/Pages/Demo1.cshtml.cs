using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Day26_Demo_RazorIntro.Pages
{
    public class Demo1Model : PageModel
    {
        //Property to bound the page 
        public string Message { get; set; } = "hello Razor Pages";
        public string? Name { get; set; } = "John Doe";
        public void OnGet()
        {
            Message = "This was set in OnGet() method";
            // this method is called when the page is requested via get request
        }
        public void OnPost()
        {
            Message = "This was set in OnPost() method";
            Console.WriteLine(Message);

            // this method is called when the page is submitted via post request
        }                  
    }
}
