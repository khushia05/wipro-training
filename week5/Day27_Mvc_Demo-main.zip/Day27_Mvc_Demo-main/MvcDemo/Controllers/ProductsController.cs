﻿using Microsoft.AspNetCore.Mvc;
using MvcDemo.Models;
namespace MvcDemo.Controllers
{
    public class ProductsController : Controller
    {
        // controllers are responsible for handling user request and returning responses
        public IActionResult Index()
        {
            var products = new List<Product>
            {
                new Product { Id=1,Name="Laptop", Price=999.00M} ,
                 new Product { Id=2,Name="Mouse", Price=250.00M},
                  new Product { Id=3,Name="Printer", Price=550.00M }

            };
            return View(products);


        }


        //Get: 
        public IActionResult Create()
        {
            return View();
        }
        //Post: /products/create (handling form submittion
        [HttpPost]
        [AutoValidateAntiforgeryToken]
        public IActionResult Create(Product product)
        {
            if (ModelState.IsValid) // cheking 
            {
                return RedirectToAction("Index");
            }
            return View(product);// showing the form again with validation errors 
        }
    }
}
