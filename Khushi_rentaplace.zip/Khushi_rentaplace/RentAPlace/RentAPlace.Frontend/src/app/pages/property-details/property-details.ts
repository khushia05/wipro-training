import { Component } from '@angular/core';

@Component({
  selector: 'app-property-details',
  imports: [],
  templateUrl: './property-details.html',
  styleUrl: './property-details.css'
})
export class PropertyDetails {

}
